SHOW databases;
use focusflow;

SELECT * FROM tbl_dailycheckins;

SELECT * FROM tbl_task;
INSERT INTO tbl_task (id, timespent, timestamp, user_id)
VALUES (114, 153,'2024-09-18 02:02:08.000000', 3);







