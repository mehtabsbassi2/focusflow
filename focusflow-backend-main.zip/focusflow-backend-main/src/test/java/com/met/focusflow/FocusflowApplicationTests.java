package com.met.focusflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FocusflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
