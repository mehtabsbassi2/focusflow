package com.met.focusflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FocusflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(FocusflowApplication.class, args);
	}

}
